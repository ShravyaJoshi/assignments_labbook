package com.cg.lab11;
public class funPow {
	public static void main(String args[])
	{
		 interPow ip=(a,b)->Math.pow(a,b);
		System.out.println("Power is "+ip.funPow(5,2));
	}
}

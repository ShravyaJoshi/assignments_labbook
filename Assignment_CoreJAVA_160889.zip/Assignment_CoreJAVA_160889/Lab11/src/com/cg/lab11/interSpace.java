package com.cg.lab11;
public interface interSpace {
	String findSpace(String str) ;

}

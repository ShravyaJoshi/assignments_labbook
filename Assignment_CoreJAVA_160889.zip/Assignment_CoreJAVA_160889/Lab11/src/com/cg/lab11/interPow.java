package com.cg.lab11;
@FunctionalInterface
public interface interPow{
	public double funPow(double a,double b);
}

package com.cg.lab11;
public class findSpace {
	public static void main(String args[])
	{
		interSpace is=(a)->a.replace(""," ");
		System.out.println("Str with space "+is.findSpace("Divisha"));
	}

}

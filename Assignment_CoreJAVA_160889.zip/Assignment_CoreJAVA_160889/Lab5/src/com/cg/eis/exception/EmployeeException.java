package com.cg.eis.exception;

public class EmployeeException extends Exception{
//	public EmployeeException(String S){
//		String T=S;
//	}

	public EmployeeException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

	
  
    
}
